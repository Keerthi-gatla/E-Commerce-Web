package com.excelr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcommBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
